from django.apps import AppConfig

import rest_registration.checks  # noqa


class RestRegistrationConfig(AppConfig):
    name = 'rest_registration'
