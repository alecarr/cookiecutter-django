__version__ = "0.5.6"
default_app_config = 'rest_registration.apps.RestRegistrationConfig'
